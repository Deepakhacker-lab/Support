package com.luv2code.springboot.thymeleafdemo.controller;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.luv2code.springboot.thymeleafdemo.entity.ProductDetailsDTO;



@FeignClient(name="Product-Service", url="localhost:8100")
public interface ProductServiceProxy {
	
	@GetMapping("/GetAllProducts")
	public  List<ProductDetailsDTO> retrieveExchangeValue();


	
	
}
