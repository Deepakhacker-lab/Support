package com.luv2code.springboot.thymeleafdemo.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.luv2code.springboot.thymeleafdemo.entity.ProductDetails;
import com.luv2code.springboot.thymeleafdemo.entity.ProductDetailsDTO;
import com.luv2code.springboot.thymeleafdemo.service.ProductServiceInterface;

@RestController

public class ProductController {
	
	@Autowired
	private ProductServiceProxy productproxy;
	
	@Autowired
	private ProductServiceInterface product;

	@GetMapping("/products/getallproducts")
	public ResponseEntity<List<ProductDetailsDTO>> getAllProducts() {
		List<ProductDetailsDTO> pd= productproxy.retrieveExchangeValue();
		
		List<ProductDetailsDTO> list =product.GetAllProducts(pd);
		
		return ResponseEntity.ok().body(list);
	}
	public static byte[] decompressBytes(byte[] data) {
		Inflater inflater = new Inflater();
		inflater.setInput(data);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		try {
			while (!inflater.finished()) {
				int count = inflater.inflate(buffer);
				outputStream.write(buffer, 0, count);
			}
			outputStream.close();
		} catch (IOException ioe) {
		} catch (DataFormatException e) {
		}
		return outputStream.toByteArray();
	}
	
}
